# cadastro
Versão Python: 2.7 Versão Django: 1.7.4

Projeto de cadastro de usuários com tela de login, validação de dados e consulta ao banco sqllte. Foi utilizado Django e Bootstrap.
